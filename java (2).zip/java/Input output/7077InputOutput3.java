//Enter the integer from the user using Scanner class
import java.util.Scanner;
class A{
    public static void main(String arg[])
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter an integer :-");
        int a = s.nextInt();
        System.out.println(a);
    }
}