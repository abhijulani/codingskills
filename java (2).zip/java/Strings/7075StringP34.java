package BCA5Practical;
// Program to Print a New Line in String
public class NewLineString {

	public static void main(String[] args) 
	{
		  System.out.println("Java" + '\n' + "Programming");
	}

}
