public class DataConversion4 {

public static void main(String[] args) {
    long myLong = 123456L;
String str = Long.toString(myLong);
System.out.println(str);

}     
       

}