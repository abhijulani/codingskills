// Data conversion:- 12. How to convert Char to String.     By(7058/21)

import java.io.*;
import java.util.*;

class CTS{
 public static void main(String args[]){
   
    char d='A';
  
    String str=Character.toString(d);
System.out.println("Char is converted to string:- "+str);
}
}