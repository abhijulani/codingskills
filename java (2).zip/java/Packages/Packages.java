package pakage;
   

import java.io.*;
import java.util.*;
   

public class Packages {
     protected int a=10;
public static void main(String args[]){  
      Packages p = new Packages();
      System.out.print("protected member inside public class is"+p.a);
   }  
     
}