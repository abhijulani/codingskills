
package com.example;

public class MyPackage {
    public String publicString = "This is a public string";
    public int publicInt = 42;

    public void display() {
        System.out.println("Public method in MyPackage class");
    }
}
