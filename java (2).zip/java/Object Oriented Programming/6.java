public class Employee {
    private String name;
    private String job;
    private String title;
    private double salary;

    public Employee(String name, String job, String title, double salary) {
        this.name = name;
        this.job = job;
        this.title = title;
        this.salary = salary;
    }

    public void calculateSalary() {
        // Code to calculate the salary
    }

    public void updateSalary(double newSalary) {
        // Code to update the salary
    }
}

