/*
-   programmer:MayankDevil
-   23. Write a Java program to compute the square root of a given integer
*/ 
class Test
{
    public static void main(String args[])
    {
        int n = 2;

        System.out.println(" square root is "+(n * n));  // check value
    }
}
// the end