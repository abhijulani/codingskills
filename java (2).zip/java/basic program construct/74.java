// 74.Write a java program to replace all the 'd' characters with 'f' characters.      By Aryan chugh (7058/21)

class replacingstring{

public static void main(String args[]){
 String ar="My dog name is dooddy"; //orignal string
 
 String br=ar.replace('d','f');  //replacing 'd' with 'f'
 System.out.println("The orignal string is : ");
System.out.println(" ");
 System.out.println(ar);
System.out.println(" ");
 System.out.println("String after replacing the character d with f : ");
System.out.println(" "); 
 System.out.println(br);
}}

 

 