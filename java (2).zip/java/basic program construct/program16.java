/*
-   programmer:MayankDevil
-   16. Write a Java program to print the odd numbers from 1 to 20
*/ 
class Test
{
    public static void main(String args[])
    {
        for (int i = 1; i < 20; i += 2)
            System.out.print(i);
    }
}
// the end