/*
-   programmer:MayankDevil
-   36. Java Program to find volume of cuboid
*/ 
class Test
{
    public static void main(String args[])
    {
        double l = 2;

        double b = 3;

        double h = 2;

        System.out.println("Volume Of Cuboid is:"+(l * b * h));
    }
}
// the end