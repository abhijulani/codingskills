//calculate length of a string

class strlength
{
public static void main(String[] args){
String strng1= "WE ARE STUDENTS OF PGGC11";
String strng2= "STUDENTS";

System.out.println("String1 length  ="+strng1.length());

System.out.print("String2 length ="+strng2.length());

}
}