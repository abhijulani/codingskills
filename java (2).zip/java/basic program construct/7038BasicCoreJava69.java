class Program69{
    public static void main(String args[]){
        String str1 = "Yaman";
        String str2 = "Sahota";
        String str3 = str1.concat(str2);
        System.out.println(str3);
    }
}