//Write a java program to print current date and time in the specified format

class date{
    public static void main(String st[])
    {
        java.util.Date today = new java.util.Date();
        System.out.println("Current date and time of the system: "+ today);
    }
}