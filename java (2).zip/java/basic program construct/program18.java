/*
-   programmer:MayankDevil
-   18. Write a Java program to convert a string to an integer
*/ 
class Test
{
    public static void main(String args[])
    {
        System.out.println(Integer.parseInt("10")+2);
    }
}
// the end