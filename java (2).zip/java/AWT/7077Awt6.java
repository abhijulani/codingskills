//Create a simple awt Application that displays a Checkbox with flowLayout Manager.
class awt{
	public static void main(String[] gfdsafgvsds){
        java.awt.Frame f = new java.awt.Frame();
        java.awt.Checkbox t = new java.awt.Checkbox("Vipin");
       
		f.setSize(100,200);
		f.setVisible(true);
		f.add(t);
	}
}
